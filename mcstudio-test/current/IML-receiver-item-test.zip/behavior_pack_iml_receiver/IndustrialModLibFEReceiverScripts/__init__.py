"""FE persistent battery demo."""
