"""Adapters for vanilla blocks."""
