"""FE pulse generator demo."""
