"""Block capability providers."""
